package com.liangjiange.netty.protocol.util;

public enum SSLMODE {

    CA, CSA
}
