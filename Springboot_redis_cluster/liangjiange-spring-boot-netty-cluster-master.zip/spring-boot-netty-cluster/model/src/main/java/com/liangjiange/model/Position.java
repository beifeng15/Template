package com.liangjiange.model;

import java.io.Serializable;
import java.util.Date;

public class Position implements Serializable{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 5596028387234098848L;

	private Double longitude;
	
	private Double latitude;
	
	private String deviceId;
	
	private Date deviceTime;

	public Double getLongitude() {
		return longitude;
	}

	public void setLongitude(Double longitude) {
		this.longitude = longitude;
	}

	public Double getLatitude() {
		return latitude;
	}

	public void setLatitude(Double latitude) {
		this.latitude = latitude;
	}

	public String getDeviceId() {
		return deviceId;
	}

	public void setDeviceId(String deviceId) {
		this.deviceId = deviceId;
	}

	public Date getDeviceTime() {
		return deviceTime;
	}

	public void setDeviceTime(Date deviceTime) {
		this.deviceTime = deviceTime;
	}

}
