package com.liangjiange.listener;

public interface Observer {
	
	public void update(float temp,float humidity, float pressure);

}
