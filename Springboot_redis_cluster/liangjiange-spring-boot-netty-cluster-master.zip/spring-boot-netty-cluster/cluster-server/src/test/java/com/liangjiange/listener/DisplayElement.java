package com.liangjiange.listener;

public interface DisplayElement {
	
	public void display();

}
