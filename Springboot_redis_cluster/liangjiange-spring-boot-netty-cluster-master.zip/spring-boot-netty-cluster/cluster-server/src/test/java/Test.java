import java.nio.ByteBuffer;

import io.netty.buffer.ByteBuf;

public class Test {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ByteBuf byteBuf;
		ByteBuffer byteBuffer = ByteBuffer.allocate(20);
		String value = "一";
		byteBuffer.put(value.getBytes());
		int remain1 = byteBuffer.remaining();
		System.out.println(remain1);
		byteBuffer.flip();
		int remain = byteBuffer.remaining();
		System.out.println(remain);
		byte[] vArray = new byte[remain];
		byteBuffer.get(vArray);
		String decodeValue = new String(vArray);
		System.out.println(decodeValue);
	}

}
