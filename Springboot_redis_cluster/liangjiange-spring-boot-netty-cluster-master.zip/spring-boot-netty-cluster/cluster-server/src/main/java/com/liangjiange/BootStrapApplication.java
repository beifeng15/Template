package com.liangjiange;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BootStrapApplication{

	// Simple example shows how a command line spring application can execute an
	// injected bean service. Also demonstrates how you can use @Value to inject
	// command line args ('--name=whatever') or application properties

	public static void main(String[] args) throws Exception {
		SpringApplication.run(BootStrapApplication.class, args);
	}

}
