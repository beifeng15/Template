package com.liangjiange.netty.protocol.server;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.alibaba.fastjson.JSON;
import com.liangjiange.model.Position;
import com.liangjiange.netty.protocol.struct.NettyMessage;
import com.liangjiange.netty.protocol.util.MessageType;

import io.netty.channel.ChannelHandlerContext;
import io.netty.channel.ChannelInboundHandlerAdapter;

/**
 * 业务逻辑处理代码
 * @author GE
 *
 */
public class LogicRespHandler extends ChannelInboundHandlerAdapter {
	
	private static Logger logger = LoggerFactory.getLogger(LogicRespHandler.class);
	
	@Override
	public void channelRead(ChannelHandlerContext ctx, Object msg) throws Exception {
		
		NettyMessage message = JSON.parseObject((String) msg, NettyMessage.class);
		if (message.getHeader() != null
				&& message.getHeader().getType() == MessageType.LOGIC_REQ.value()) {
				Position position  = JSON.parseObject(message.getBody().toString(), Position.class);
				logger.debug("position="+position.getDeviceId());
		}else{
			logger.info("~~~~~~~~error resp message type~~~~~~~~~");
		}
		
	}


	public void exceptionCaught(ChannelHandlerContext ctx, Throwable cause) throws Exception {
		cause.printStackTrace();
		ctx.close();
		ctx.fireExceptionCaught(cause);
	}
}
