package com.liangjiange.init;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.BeansException;
import org.springframework.boot.CommandLineRunner;
import org.springframework.context.ApplicationContext;
import org.springframework.context.ApplicationContextAware;
import org.springframework.context.EnvironmentAware;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Component;

import com.liangjiange.netty.protocol.server.NettyServer;

@Component
public class Init implements CommandLineRunner, EnvironmentAware, ApplicationContextAware{

	private static final Logger logger = LoggerFactory.getLogger(Init.class);
	
	@Override
	public void setApplicationContext(ApplicationContext arg0) throws BeansException {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void setEnvironment(Environment arg0) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void run(String... arg0) throws Exception {
		// TODO Auto-generated method stub
		logger.info("=================================================");
		logger.info("============Project Lcenter start==================");
		logger.info("=================================================");
		new NettyServer().bind();
	}

}
