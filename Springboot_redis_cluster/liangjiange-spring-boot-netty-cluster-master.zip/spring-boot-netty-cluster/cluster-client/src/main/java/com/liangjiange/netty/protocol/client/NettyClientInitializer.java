/*
 * Copyright 2012 The Netty Project
 *
 * The Netty Project licenses this file to you under the Apache License,
 * version 2.0 (the "License"); you may not use this file except in compliance
 * with the License. You may obtain a copy of the License at:
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
 * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
 * License for the specific language governing permissions and limitations
 * under the License.
 */
package com.liangjiange.netty.protocol.client;

import java.util.concurrent.TimeUnit;

import javax.net.ssl.SSLEngine;

import com.liangjiange.netty.protocol.util.NettySslContextFactory;
import com.liangjiange.netty.protocol.util.SSLMODE;

import io.netty.channel.ChannelInitializer;
import io.netty.channel.ChannelPipeline;
import io.netty.channel.socket.SocketChannel;
import io.netty.handler.codec.string.StringDecoder;
import io.netty.handler.codec.string.StringEncoder;
import io.netty.handler.ssl.SslHandler;
import io.netty.handler.timeout.IdleStateHandler;
import io.netty.handler.timeout.ReadTimeoutHandler;

/**
 * Creates a newly configured {@link ChannelPipeline} for a new channel.
 */
public class NettyClientInitializer extends
	ChannelInitializer<SocketChannel> {

    private String tlsMode;

    public NettyClientInitializer(String tlsMode) {
	this.tlsMode = tlsMode;
    }
    private final static int readerIdleTimeSeconds = 10;//读操作空闲30秒
	private final static int writerIdleTimeSeconds = 15;//写操作空闲60秒
	private final static int allIdleTimeSeconds = 30;//读写全部空闲100秒

    @Override
    public void initChannel(SocketChannel ch) throws Exception {
	ChannelPipeline pipeline = ch.pipeline();

	SSLEngine engine = null;
	if (SSLMODE.CA.toString().equals(tlsMode)) {
	    engine = NettySslContextFactory
		    .getClientContext(
			    tlsMode,
			    null,
			    System.getProperty("user.dir")
				    + "/src/main/resources/cChat.jks")
		    .createSSLEngine();
	} else if (SSLMODE.CSA.toString().equals(tlsMode)) {
	    engine = NettySslContextFactory
		    .getClientContext(
			    tlsMode,
			    System.getProperty("user.dir")
				    + "/src/main/resources/cChat.jks",
			    System.getProperty("user.dir")
				    + "/src/main/resources/cChat.jks")
		    .createSSLEngine();

	} else {
	    System.err.println("ERROR : " + tlsMode);
	    System.exit(-1);
	}
	engine.setUseClientMode(true);
	pipeline.addLast("ssl", new SslHandler(engine));

	pipeline.addLast("decoder", new StringDecoder());
	pipeline.addLast("encoder", new StringEncoder());
	pipeline.addLast("readTimeoutHandler", new ReadTimeoutHandler(50));
	pipeline.addLast("LoginAuthHandler", new LoginAuthReqHandler());
	pipeline.addLast(new IdleStateHandler(readerIdleTimeSeconds, writerIdleTimeSeconds, allIdleTimeSeconds, TimeUnit.SECONDS));
	pipeline.addLast("HeartBeatHandler", new HeartBeatReqHandler());
	pipeline.addLast("logicReqHandler", new LogicReqHandler());
    }
}
